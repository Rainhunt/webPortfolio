import { ListsManager } from "./ListManager.js";

new ListsManager("newListKey", "#lists-wrapper", "#new-list-text-input", "#create-new-list-button");
